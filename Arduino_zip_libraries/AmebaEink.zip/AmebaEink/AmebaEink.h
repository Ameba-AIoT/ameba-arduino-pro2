#ifndef _AMEBA_EINK_H_
#define _AMEBA_EINK_H_

#endif
