#ifndef MODEL_CENTERFACE_H
#define MODEL_CENTERFACE_H

#include "module_vipnn.h"

extern nnmodel_t centerface_fwfs;

#endif /* MODEL_CENTERFACE_H */