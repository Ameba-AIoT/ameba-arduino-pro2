#ifndef ATCMD_XMODEM_H
#define ATCMD_XMODEM_H

extern void xmodem_atcmd_init(void);

#endif
