1. Put IAR linker script file(.icf) here.
2. The ROM code symbole file will be put here.