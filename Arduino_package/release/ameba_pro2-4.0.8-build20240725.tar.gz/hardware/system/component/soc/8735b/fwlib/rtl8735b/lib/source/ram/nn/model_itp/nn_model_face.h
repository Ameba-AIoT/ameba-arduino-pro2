#include "nn_api_config.h"

#if MODEL_FACE_USED

extern const unsigned int nnmodel_face_ro[];

#endif //MODEL_FACE_USED
