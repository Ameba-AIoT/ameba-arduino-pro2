#ifndef _DWC_OS_DEP_H_
#define _DWC_OS_DEP_H_
#include "usb_errno.h"

#endif /* _DWC_OS_DEP_H_ */
