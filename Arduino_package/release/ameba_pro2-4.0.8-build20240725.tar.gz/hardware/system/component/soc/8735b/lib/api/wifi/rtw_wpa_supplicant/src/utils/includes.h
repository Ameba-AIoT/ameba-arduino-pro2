#ifndef INCLUDES_H
#define INCLUDES_H

#define CONFIG_NO_STDOUT_DEBUG

//#define DBG_871X(...)  vTaskDelay(100)
//DBG_871X_LEVEL(_drv_always_, "no beacon for a long time, disconnect or roaming\n");
//#define DBG_871X(...) DBG_871X_LEVEL(_drv_always_,...)

#endif /* INCLUDES_H */
