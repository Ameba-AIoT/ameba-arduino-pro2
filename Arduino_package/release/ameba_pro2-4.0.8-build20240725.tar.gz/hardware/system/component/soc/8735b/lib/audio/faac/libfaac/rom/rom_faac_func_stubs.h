#ifndef ROM_FAAC_FUNC_STUBS_H
#define ROM_FAAC_FUNC_STUBS_H

typedef struct faac_func_stubs_s {
	float *pow43_res_table;
	float *adj43_res_table;
} faac_func_stubs_t;

#endif // ROM_FAAC_FUNC_STUBS_H