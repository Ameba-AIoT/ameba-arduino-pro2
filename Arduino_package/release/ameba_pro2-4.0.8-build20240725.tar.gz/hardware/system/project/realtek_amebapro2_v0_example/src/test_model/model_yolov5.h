#ifndef _MODEL_YOLOV5_H_
#define _MODEL_YOLOV5_H_

#include "module_vipnn.h"

extern nnmodel_t yolov5;

#endif /* _MODEL_YOLOV5_H_ */