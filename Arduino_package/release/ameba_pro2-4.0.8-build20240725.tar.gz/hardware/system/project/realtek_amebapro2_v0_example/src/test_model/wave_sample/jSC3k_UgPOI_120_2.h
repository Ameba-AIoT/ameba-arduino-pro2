extern unsigned char jSC3k_UgPOI_120_2_wav[];
extern unsigned int jSC3k_UgPOI_120_2_wav_len;
