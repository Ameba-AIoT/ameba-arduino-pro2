extern unsigned char DCBOS2UWKAA_30_0_wav[];
extern unsigned int DCBOS2UWKAA_30_0_wav_len;
