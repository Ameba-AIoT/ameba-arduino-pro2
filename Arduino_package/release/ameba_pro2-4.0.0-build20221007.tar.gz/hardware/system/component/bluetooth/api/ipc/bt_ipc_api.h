/**
*****************************************************************************************
*     Copyright(c) 2021, Realtek Semiconductor Corporation. All rights reserved.
*****************************************************************************************
  * @file     bt_ipc_api.h
  * @brief    Head file for bt ipc api.
  * @details  bt ipc api.
  * @author   sherman
  * @date     2021-10-20
  * @version  v1.0
  * *************************************************************************************
  */

#ifndef _BT_IPC_API_H_
#define _BT_IPC_API_H_

#endif /* _BT_IPC_API_H_ */