extern unsigned char examples_baby_975ms_wav[];
extern unsigned int examples_baby_975ms_wav_len;
