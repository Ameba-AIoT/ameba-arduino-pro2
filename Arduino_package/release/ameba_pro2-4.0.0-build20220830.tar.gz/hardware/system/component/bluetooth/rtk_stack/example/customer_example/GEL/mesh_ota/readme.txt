Mesh OTA Test

Description:
This example shows how to execute mesh ota test flow in amebaz2 platform

Configuration:
	Replace libraries and head files in ~\amazon 
	lib to sdk\component\common\bluetooth\realtek\sdk\example\bt_mesh\lib\lib\amebaz2
	head files to sdk\component\common\bluetooth\realtek\sdk\example\bt_mesh\lib\model

Steps to use:
	ATBM=pro,fuig,0x100,0,0,0
	ATBM=mesh_ota,0x100,0,9

[Supported List]
	Supported :
	    Ameba-z2