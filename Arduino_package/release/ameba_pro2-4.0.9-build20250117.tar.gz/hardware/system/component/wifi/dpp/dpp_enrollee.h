#ifndef __DPP_ENROLLEE_H__
#define __DPP_ENROLLEE_H__

#include "dpp.h"

int DPP_Init_Enrollee(dpp_adapter *pdpp_adapter)
#endif