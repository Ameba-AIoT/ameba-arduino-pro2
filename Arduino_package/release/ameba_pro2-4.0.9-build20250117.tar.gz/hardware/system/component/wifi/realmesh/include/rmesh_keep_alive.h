#ifndef _RTL_MESH_KEEP_ALIVE_H_
#define _RTL_MESH_KEEP_ALIVE_H_


void real_mesh_keep_alive_timer_init();
void real_mesh_ota_ongoing_timeout(u8	node_type);

#endif //_RTL_MESH_KEEP_ALIVE_H_