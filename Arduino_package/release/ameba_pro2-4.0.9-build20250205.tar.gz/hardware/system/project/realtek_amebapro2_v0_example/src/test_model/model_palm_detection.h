#pragma once
#ifndef MODEL_PALM_DETECTION_H
#define MODEL_PALM_DETECTION_H
#include "module_vipnn.h"
extern nnmodel_t palm_detection_fwfs;
#endif
