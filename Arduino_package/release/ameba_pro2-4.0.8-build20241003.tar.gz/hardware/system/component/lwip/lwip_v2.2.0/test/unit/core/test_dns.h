#ifndef LWIP_HDR_TEST_DNS_H
#define LWIP_HDR_TEST_DNS_H

#include "../lwip_check.h"

Suite *dns_suite(void);

#endif
