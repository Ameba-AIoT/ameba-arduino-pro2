#ifndef _VERSION_H_
#define _VERSION_H_

#define FAAC_RELEASE 1

#define FAAC_VERSION "1.28"

#endif
