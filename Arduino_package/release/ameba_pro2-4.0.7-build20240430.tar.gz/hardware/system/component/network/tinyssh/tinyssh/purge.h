#ifndef _PURGE_H____
#define _PURGE_H____

#include "cleanup.h"
#define purge cleanup_

#endif
