#ifndef _UINT32_UNPACK_H____
#define _UINT32_UNPACK_H____

#include "crypto_uint32.h"

extern crypto_uint32 uint32_unpack(const unsigned char *);

#endif
