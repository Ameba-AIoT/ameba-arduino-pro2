#ifndef _IPTOSTR_H____
#define _IPTOSTR_H____

#define IPTOSTR_LEN 46

extern char *iptostr(char *, const unsigned char *);

#endif
