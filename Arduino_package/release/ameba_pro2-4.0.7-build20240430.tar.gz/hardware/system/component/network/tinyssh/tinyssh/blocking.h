#ifndef BLOCKING_H
#define BLOCKING_H

extern void blocking_enable(int);
extern void blocking_disable(int);

#endif
