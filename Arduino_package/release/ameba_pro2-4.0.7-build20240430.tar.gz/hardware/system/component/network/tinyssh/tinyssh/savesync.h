#ifndef SAVESYNC_H
#define SAVESYNC_H

extern int savesync(const char *, const void *, long long);

#endif
