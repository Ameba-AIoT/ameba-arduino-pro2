#ifndef crypto_uint32_h
#define crypto_uint32_h

#include <stdint.h>

typedef uint32_t crypto_uint32;

#endif
