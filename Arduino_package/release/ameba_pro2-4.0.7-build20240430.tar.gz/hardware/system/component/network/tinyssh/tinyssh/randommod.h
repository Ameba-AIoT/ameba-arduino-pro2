#ifndef _RANDOMMOD_H____
#define _RANDOMMOD_H____

extern long long randommod(long long);

#endif
