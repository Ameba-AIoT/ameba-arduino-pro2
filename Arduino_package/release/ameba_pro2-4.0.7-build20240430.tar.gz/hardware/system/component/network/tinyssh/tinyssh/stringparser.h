#ifndef _STRINGPARSER_H____
#define _STRINGPARSER_H____

extern long long stringparser(const unsigned char *, long long, long long,  unsigned char **, long long *);

#endif
