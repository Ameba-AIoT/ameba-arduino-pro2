#ifndef _DROPUIDGID_H____
#define _DROPUIDGID_H____

#include <sys/types.h>
extern int dropuidgid(const char *, uid_t, gid_t);

#endif
