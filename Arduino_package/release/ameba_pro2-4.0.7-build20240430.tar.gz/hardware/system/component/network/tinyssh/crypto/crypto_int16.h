#ifndef crypto_int16_h
#define crypto_int16_h

#include <stdint.h>

typedef int16_t crypto_int16;

#endif
