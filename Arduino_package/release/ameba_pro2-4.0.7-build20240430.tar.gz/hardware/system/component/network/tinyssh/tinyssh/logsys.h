/* Public domain. */

#ifndef _LOGSYS_H____
#define _LOGSYS_H____

void logsys_login(const char *, const char *, const char *, long long);
void logsys_logout(const char *, const char *, const char *, long long);

#endif
