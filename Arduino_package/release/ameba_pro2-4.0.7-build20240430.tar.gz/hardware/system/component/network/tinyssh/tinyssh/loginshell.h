#ifndef _LOGINSHELL_H____
#define _LOGINSHELL_H____

extern int loginshell(char *, long long, const char *);

#endif
