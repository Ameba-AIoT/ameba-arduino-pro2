#ifndef _SDCARD_H_
#define _SDCARD_H_
#include "fatfs_ext/inc/ff_driver.h"
#include "cmsis.h"
#include "platform_opts.h"

extern ll_diskio_drv SD_disk_Driver;
#endif
