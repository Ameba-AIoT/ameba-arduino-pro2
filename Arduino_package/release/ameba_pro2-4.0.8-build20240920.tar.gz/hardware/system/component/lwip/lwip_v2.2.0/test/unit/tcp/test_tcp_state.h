#ifndef LWIP_HDR_TEST_TCP_STATE_H
#define LWIP_HDR_TEST_TCP_STATE_H

#include "../lwip_check.h"

Suite *tcp_state_suite(void);

#endif
