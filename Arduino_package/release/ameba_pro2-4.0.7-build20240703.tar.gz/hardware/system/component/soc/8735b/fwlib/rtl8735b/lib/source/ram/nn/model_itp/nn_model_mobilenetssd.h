#include "nn_api_config.h"

#if MODEL_SSDM_USED

extern const unsigned int nnmodel_sm_ro[];

#endif //MODEL_SSDM_USED
