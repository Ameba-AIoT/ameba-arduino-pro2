#ifndef _FLASH_FATFS_H_
#define _FLASH_FATFS_H_
#include "ff_driver.h"

extern ll_diskio_drv FLASH_disk_Driver;
#endif
