void nn_dtypetofloat(
	unsigned char id,
	unsigned char *tensor0out_nn,
	unsigned char *tensor1out_nn,
	unsigned int  *tensor0out_fp,
	unsigned int  *tensor1out_fp
);


