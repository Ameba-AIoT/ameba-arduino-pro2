extern unsigned char chi_bin_custom[];
extern unsigned int chi_bin_len_custom;
extern unsigned char eng_bin_custom[];
extern unsigned int eng_bin_len_custom;
