#include "nn_model_info.h"

extern float  tensor0out_mem[MAX_LOCA_NUM * 4];
extern float  tensor1out_mem[MAX_LOCA_NUM * MAX_CLASS_NUM];

