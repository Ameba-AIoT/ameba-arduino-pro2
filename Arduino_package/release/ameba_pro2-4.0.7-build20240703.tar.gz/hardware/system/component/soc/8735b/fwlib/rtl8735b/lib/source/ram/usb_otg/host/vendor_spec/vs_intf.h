/*
header file for vendor spec driver
*/

int vs_init(void); //entry function to start vs
void vs_free(void);

